import sqlite3 from "sqlite3";
import { open } from "sqlite";

export async function initDb(sqliteFile) {
  const db = await open({
    filename: sqliteFile,
    driver: sqlite3.Database
  });

  await db.exec(`PRAGMA foreign_keys = ON;`);

  await db.exec(`
    CREATE TABLE IF NOT EXISTS activities (
      code TEXT PRIMARY KEY,
      title TEXT NOT NULL,
      description TEXT NOT NULL,
      startsAt INTEGER NOT NULL,
      endsAt INTEGER NOT NULL,
      createdAt INTEGER NOT NULL
    );
  `);

  await db.exec(`
    CREATE TABLE IF NOT EXISTS feedback (
      id INTEGER PRIMARY KEY AUTOINCREMENT,
      code TEXT NOT NULL,
      type TEXT NOT NULL CHECK(type IN ('happy','sad','surprised','confused')),
      ts INTEGER NOT NULL,
      FOREIGN KEY(code) REFERENCES activities(code) ON DELETE CASCADE
    );
  `);

  await db.exec(`
    CREATE INDEX IF NOT EXISTS idx_feedback_code_ts
    ON feedback(code, ts);
  `);

  return db;
}
