import express from "express";
import cors from "cors";
import env from "dotenv";
import http from "http";
import { Server } from "socket.io";
import { initDb } from "./db.js";

env.config();

function nowMs() { return Date.now(); }

function isActive(act) {
  const t = nowMs();
  return t >= Number(act.startsAt) && t <= Number(act.endsAt);
}

function makeCode(len = 6) {
  const chars = "ABCDEFGHJKLMNPQRSTUVWXYZ23456789";
  let s = "";
  for (let i = 0; i < len; i++) s += chars[Math.floor(Math.random() * chars.length)];
  return s;
}

const app = express();
app.use(cors());
app.use(express.json());

const server = http.createServer(app);
const io = new Server(server, { cors: { origin: "*" } });

const PORT = Number(process.env.PORT || 3001);
const SQLITE_FILE = process.env.SQLITE_FILE || "./feedback.sqlite";

async function start() {
  const db = await initDb(SQLITE_FILE);

  // REST API 

  // Professor creates activity
  app.post("/api/activities", async (req, res) => {
    try {
      const { title, description, startsAt, endsAt } = req.body;

      if (!title || !description || !startsAt || !endsAt) {
        return res.status(400).json({ error: "Missing fields: title, description, startsAt, endsAt" });
      }

      const s = Number(startsAt);
      const e = Number(endsAt);

      if (!Number.isFinite(s) || !Number.isFinite(e) || s >= e) {
        return res.status(400).json({ error: "Invalid startsAt/endsAt" });
      }

      let code;
      while (true) {
        code = makeCode(6);
        const existing = await db.get("SELECT code FROM activities WHERE code = ?", [code]);
        if (!existing) break;
      }

      const createdAt = nowMs();

      await db.run(
        `INSERT INTO activities(code, title, description, startsAt, endsAt, createdAt)
         VALUES(?, ?, ?, ?, ?, ?)`,
        [code, title, description, s, e, createdAt]
      );

      const act = await db.get("SELECT * FROM activities WHERE code = ?", [code]);
      res.json({ ...act, active: isActive(act) });
    } catch {
      res.status(500).json({ error: "Server error creating activity" });
    }
  });

  // Professor lists all activities
  app.get("/api/activities", async (req, res) => {
    try {
      const rows = await db.all(
        `SELECT a.*,
                (SELECT COUNT(*) FROM feedback f WHERE f.code = a.code) AS feedbackCount
         FROM activities a
         ORDER BY a.createdAt DESC`
      );

      res.json(rows.map(r => ({
        ...r,
        active: isActive(r),
        feedbackCount: Number(r.feedbackCount)
      })));
    } catch {
      res.status(500).json({ error: "Server error listing activities" });
    }
  });

  // Get activity by code
  app.get("/api/activities/:code", async (req, res) => {
    try {
      const code = req.params.code.toUpperCase();
      const act = await db.get("SELECT * FROM activities WHERE code = ?", [code]);
      if (!act) return res.status(404).json({ error: "Activity not found" });
      res.json({ ...act, active: isActive(act) });
    } catch {
      res.status(500).json({ error: "Server error reading activity" });
    }
  });

  // Professor gets feedback history
  app.get("/api/feedback/:code", async (req, res) => {
    try {
      const code = req.params.code.toUpperCase();

      const act = await db.get("SELECT code FROM activities WHERE code = ?", [code]);
      if (!act) return res.status(404).json({ error: "Activity not found" });

      const items = await db.all(
        "SELECT type, ts FROM feedback WHERE code = ? ORDER BY ts ASC",
        [code]
      );

      res.json(items);
    } catch {
      res.status(500).json({ error: "Server error reading feedback" });
    }
  });

  // Socket.IO 

  io.on("connection", (socket) => {

    socket.on("joinActivity", async ({ code, role }) => {
      const c = String(code || "").toUpperCase();
      const act = await db.get("SELECT * FROM activities WHERE code = ?", [c]);

      if (!act) return socket.emit("errorMessage", { error: "Activity not found" });

      const r = String(role || "student").toLowerCase();

   
      if (r === "student" && !isActive(act)) {
        return socket.emit("errorMessage", { error: "Activity is not active (students can join only during the time window)" });
      }

      socket.join(`activity:${c}`);
      socket.emit("joined", { code: c });
    });

    socket.on("sendReaction", async ({ code, type }) => {
      const c = String(code || "").toUpperCase();
      const act = await db.get("SELECT * FROM activities WHERE code = ?", [c]);

      if (!act) return socket.emit("errorMessage", { error: "Activity not found" });
      if (!isActive(act)) return socket.emit("errorMessage", { error: "Activity is not active" });

      const allowed = new Set(["happy", "sad", "surprised", "confused"]);
      if (!allowed.has(type)) return;

      const item = { type, ts: nowMs() };

      await db.run(
        "INSERT INTO feedback(code, type, ts) VALUES(?, ?, ?)",
        [c, item.type, item.ts]
      );

      io.to(`activity:${c}`).emit("newReaction", { code: c, ...item });
    });
  });

  server.listen(PORT, () => console.log(`Backend running on http://localhost:${PORT}`));
}

start();
