import { io } from "socket.io-client";
import "./style.css";

const API = "http://localhost:3001";
const socket = io(API);

const app = document.querySelector("#app");

function fmtTime(ms) {
  return new Date(Number(ms)).toLocaleString();
}
function emojiFor(type) {
  if (type === "happy") return "🙂";
  if (type === "sad") return "🙁";
  if (type === "surprised") return "😮";
  if (type === "confused") return "😕";
  return "❓";
}

async function apiGet(path) {
  const res = await fetch(`${API}${path}`);
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}
async function apiPost(path, body) {
  const res = await fetch(`${API}${path}`, {
    method: "POST",
    headers: { "Content-Type": "application/json" },
    body: JSON.stringify(body)
  });
  const data = await res.json();
  if (!res.ok) throw new Error(data.error || "Request failed");
  return data;
}

function renderHome() {
  app.innerHTML = `
    <div class="container">
      <h1>Continuous Feedback</h1>
      <div class="row">
        <button id="prof">Professor</button>
        <button id="stud">Student</button>
      </div>
    </div>
  `;
  document.querySelector("#prof").onclick = renderProfessorMenu;
  document.querySelector("#stud").onclick = renderStudentJoin;
}

function renderProfessorMenu() {
  app.innerHTML = `
    <div class="container">
      <h1>Professor</h1>
      <div class="row">
        <button id="create">Create activity</button>
        <button id="list">All activities</button>
        <button id="home">Home</button>
      </div>
      <div id="content"></div>
    </div>
  `;
  document.querySelector("#home").onclick = renderHome;
  document.querySelector("#create").onclick = renderProfessorCreate;
  document.querySelector("#list").onclick = renderProfessorList;
  renderProfessorCreate();
}

function renderProfessorCreate() {
  const content = document.querySelector("#content");
  content.innerHTML = `
    <div class="card">
      <h2>Create activity</h2>

      <label>Title</label>
      <input id="title" />

      <label>Description</label>
      <textarea id="desc" rows="3"></textarea>

      <label>Start</label>
      <input id="start" type="datetime-local" />

      <label>End</label>
      <input id="end" type="datetime-local" />

      <div class="row">
        <button id="save">Create</button>
      </div>

      <p id="msg"></p>
    </div>
  `;

  document.querySelector("#save").onclick = async () => {
    const msg = document.querySelector("#msg");
    msg.textContent = "";

    try {
      const title = document.querySelector("#title").value.trim();
      const description = document.querySelector("#desc").value.trim();
      const s = document.querySelector("#start").value;
      const e = document.querySelector("#end").value;

      const startsAt = s ? new Date(s).getTime() : NaN;
      const endsAt = e ? new Date(e).getTime() : NaN;

      const act = await apiPost("/api/activities", { title, description, startsAt, endsAt });

      msg.innerHTML = `
        Code: <b>${act.code}</b><br/>
        Start: ${fmtTime(act.startsAt)}<br/>
        End: ${fmtTime(act.endsAt)}<br/><br/>
        <button id="open">Open dashboard</button>
      `;
      document.querySelector("#open").onclick = () => renderProfessorDashboard(act.code);
    } catch (err) {
      msg.textContent = err.message;
    }
  };
}

async function renderProfessorList() {
  const content = document.querySelector("#content");
  content.innerHTML = `<div class="card">Loading...</div>`;

  try {
    const acts = await apiGet("/api/activities");
    content.innerHTML = `
      <div class="card">
        <h2>All activities</h2>
        ${acts.map(a => `
          <div class="item">
            <div>
              <b>${a.title}</b> — ${a.description}<br/>
              Code: <b>${a.code}</b> | Active: ${a.active ? "YES" : "NO"} | Feedback: ${a.feedbackCount}<br/>
              ${fmtTime(a.startsAt)} → ${fmtTime(a.endsAt)}
            </div>
            <button data-code="${a.code}">Open</button>
          </div>
        `).join("")}
      </div>
    `;

    document.querySelectorAll("button[data-code]").forEach(btn => {
      btn.onclick = () => renderProfessorDashboard(btn.getAttribute("data-code"));
    });
  } catch (err) {
    content.innerHTML = `<div class="card">${err.message}</div>`;
  }
}

async function renderProfessorDashboard(code) {
  const content = document.querySelector("#content");
  const c = code.toUpperCase();

  socket.emit("joinActivity", { code: c, role: "professor" });

  content.innerHTML = `
    <div class="card">
      <h2>Dashboard: ${c}</h2>
      <p id="info"></p>
      <button id="load">Load history</button>
      <div id="feed"></div>
      <p id="err" class="err"></p>
    </div>
  `;

  const info = document.querySelector("#info");
  const feed = document.querySelector("#feed");
  const err = document.querySelector("#err");

  try {
    const act = await apiGet(`/api/activities/${c}`);
    info.textContent = `${act.title} | Active: ${act.active ? "YES" : "NO"}`;
  } catch (e) {
    err.textContent = e.message;
  }

  function addItem(item) {
    const div = document.createElement("div");
    div.className = "feedItem";
    div.innerHTML = `<span>${emojiFor(item.type)} ${item.type}</span><span>${fmtTime(item.ts)}</span>`;
    feed.prepend(div);
  }

  async function loadHistory() {
    err.textContent = "";
    feed.innerHTML = "";
    try {
      const items = await apiGet(`/api/feedback/${c}`);
      items.forEach(addItem);
      if (items.length === 0) feed.innerHTML = `<small>No feedback yet.</small>`;
    } catch (e) {
      err.textContent = e.message;
    }
  }

  document.querySelector("#load").onclick = loadHistory;
  await loadHistory();

  socket.off("newReaction");
  socket.on("newReaction", (item) => {
    if (item.code !== c) return;
    addItem(item);
  });

  socket.off("errorMessage");
  socket.on("errorMessage", (e) => {
    err.textContent = e.error || "Socket error";
  });
}

function renderStudentJoin() {
  app.innerHTML = `
    <div class="container">
      <h1>Student</h1>
      <div class="row">
        <button id="home">Home</button>
      </div>

      <div class="card">
        <label>Activity code</label>
        <input id="code" />
        <div class="row">
          <button id="join">Join</button>
        </div>
        <p id="msg"></p>
      </div>

      <div id="content"></div>
    </div>
  `;

  document.querySelector("#home").onclick = renderHome;

  document.querySelector("#join").onclick = async () => {
    const msg = document.querySelector("#msg");
    msg.textContent = "";
    const code = document.querySelector("#code").value.trim().toUpperCase();

    try {
      const act = await apiGet(`/api/activities/${code}`);
      if (!act.active) throw new Error("Activity is not active. Students can join only during the time window.");
      renderStudentPanel(code);
    } catch (e) {
      msg.textContent = e.message;
    }
  };
}

async function renderStudentPanel(code) {
  const content = document.querySelector("#content");
  const c = code.toUpperCase();

  socket.emit("joinActivity", { code: c, role: "student" });

  const act = await apiGet(`/api/activities/${c}`);

  content.innerHTML = `
    <div class="card">
      <h2>${c}</h2>
      <div>${act.title}</div>
      <small>Active: ${act.active ? "YES" : "NO"}</small>

      <div class="grid4">
        <button data-type="happy">🙂</button>
        <button data-type="sad">🙁</button>
        <button data-type="surprised">😮</button>
        <button data-type="confused">😕</button>
      </div>

      <p id="status"></p>
    </div>
  `;

  const status = document.querySelector("#status");

  document.querySelectorAll("button[data-type]").forEach(btn => {
    btn.onclick = () => {
      const type = btn.getAttribute("data-type");
      socket.emit("sendReaction", { code: c, type });
      status.textContent = `Sent ${emojiFor(type)} at ${fmtTime(Date.now())}`;
    };
  });

  socket.off("errorMessage");
  socket.on("errorMessage", (e) => {
    status.textContent = e.error || "Error";
  });
}

renderHome();

